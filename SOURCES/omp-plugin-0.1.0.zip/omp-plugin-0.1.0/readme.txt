=== OnMyPlate.co.uk Plugin ===
Contributors: woolie
Donate link: http://onmyplate.co.uk
Tags: food, recipe, parser, markdown
Requires at least: 3.3.1
Tested up to: 3.3.1
Stable tag: 0.1.0

The OnMyPlate.co.uk Plugin (omp-plugin) provides functions needed by the
OnMyPlate.co.uk Theme (omp-theme). Containins a PHP parser for OnMyPlate.co.uk
Markup Language (omp-ml).


== Description ==
The OnMyPlate.co.uk Plugin (omp-plugin) provides functions needed by the
OnMyPlate.co.uk Theme (omp-theme). Containins a PHP parser for OnMyPlate.co.uk
Markup Language (omp-ml).


== Installation ==
Pre-Requirements:
1. The Zend Framework is within `/usr/share/php/libzend-framework-php/`. E.g.
   for Ubuntu: `apt-get install zend-framework`.

=== From .tgz ===
1. Upload the `omp-plugin-0.1.0.tgz` to your `wp-content/plugins/`
2. Extract the archive: `tar -zxf omp-plugin-0.1.0.tgz ./`
3. Disable the older version annd activate the new version of the plugin through
   the 'Plugins' menu in WordPress


== Frequently Asked Questions ==
= What happens if multiple versions of the plugin are enabled at once  =


== Screenshots ==
1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot


== Changelog ==
= 0.1.0 =
* Initial release


== Upgrade Notice ==
